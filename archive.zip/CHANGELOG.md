# Changelog

## 1.0.0 – 2023-08-04

### Added

- initial release
